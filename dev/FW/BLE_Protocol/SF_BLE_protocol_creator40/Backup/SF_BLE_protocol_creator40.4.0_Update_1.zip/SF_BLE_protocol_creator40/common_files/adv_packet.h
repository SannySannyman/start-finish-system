#ifndef ADV_PACKET_H
    #define ADV_PACKET_H
    
#include "project.h"

#define BLE_ADV_PACKET_COUNT    5
#define BLE_ADV_PACKET_TEXTLEN  4
#define BLE_ADV_PACKET_TEXTBUFLEN  (BLE_ADV_PACKET_TEXTLEN+1)
#define BLE_ADV_PACKET_ENDBYTE      (0xDD)
#define BLE_CUSTOM_SERVICE_UUID_LSB (0xA1)
#define BLE_CUSTOM_SERVICE_UUID_MSB (0xE5)

    
enum
{
    ADV_PACKET_UUID_DATALEN = 3,
    ADV_PACKET_SERVICEDATA,
    ADV_PACKET_UUID_LSB,
    ADV_PACKET_UUID_MSB,
    
    ADV_PACKET_SKIER_NUM,
    ADV_PACKET_STATUS_BYTE,
    
    ADV_PACKET_TIME_START_B3,
    ADV_PACKET_TIME_START_B2,
    ADV_PACKET_TIME_START_B1,
    ADV_PACKET_TIME_START_B0,
     
    ADV_PACKET_TIME_FINISH_B3,
    ADV_PACKET_TIME_FINISH_B2,
    ADV_PACKET_TIME_FINISH_B1,
    ADV_PACKET_TIME_FINISH_B0,
    
    ADV_PACKET_TIME_RESULT_B3,
    ADV_PACKET_TIME_RESULT_B2,
    ADV_PACKET_TIME_RESULT_B1,
    ADV_PACKET_TIME_RESULT_B0,
    
    ADV_PACKET_TXT_START,
    
    ADV_PACKET_ENDBYTE = ADV_PACKET_TXT_START + BLE_ADV_PACKET_TEXTLEN,
    ADV_PACKET_LEN
    
};    
    
enum
{
    STATUS_STARTED = 1,
    STATUS_FINISHED,
    STATUS_CANCELED
};

typedef struct
{
    uint8 SkierNum;
    uint8 StatusByte;
    uint32 TimeStart;
    uint32 TimeFinish;
    uint32 TimeResult;
    char Text[BLE_ADV_PACKET_TEXTBUFLEN];
}BLE_advPacketData_t;
    

typedef struct
{
    BLE_advPacketData_t Data[BLE_ADV_PACKET_COUNT];
    uint8 ItemNum;
    uint8 NextItem;
}BLE_advPacketsContent_t;



#endif