/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "..\common_files\debug.h"
#include "bluetooth.h"
#include <stdio.h>


CY_ISR(isr_Timer_Handler)
{
    BLE_ADV_NextPacket();
    Timer_ClearInterrupt(Timer_INTR_MASK_TC);
}

int main(void)
{
    BLE_advPacketData_t data;
    
    uint8 result;
    uint8 i = 0;
    uint8 cnt = 0;
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    DEBUG_Init();
    
    Timer_Start();
    isr_Timer_StartEx(isr_Timer_Handler);
    BLE_Start();
    
    data.SkierNum = 1;
    data.StatusByte = STATUS_STARTED;
    data.TimeStart = 0x12345678;
    data.TimeFinish = 0x87654321;
    data.TimeResult = 0x11223344;
    snprintf(data.Text, BLE_ADV_PACKET_TEXTBUFLEN, "QW");
    
    BLE_ADV_AddData(&data);
    
    data.SkierNum = 42;
    data.StatusByte = STATUS_FINISHED;
    data.TimeStart = 0x44444444;
    data.TimeFinish = 0x22222222;
    data.TimeResult = i;
    snprintf(data.Text, BLE_ADV_PACKET_TEXTBUFLEN, "Time");
    
    BLE_ADV_AddData(&data);
    

    
    for(;;)
    {
        CyBle_ProcessEvents();
        
        result = BLE_ADV_Process();
        if(result == BLE_ADV_PACKET_UPDATED)
        {
            cnt++;
            if(cnt >= 10)
            {
                cnt = 0;
                
                i++;
                data.StatusByte = i%3 +1;
                data.TimeResult = i;
                data.SkierNum = i;
                BLE_ADV_AddData(&data);
            }
            Pin_GreenLED_Write(~Pin_GreenLED_Read());
        }
        
        
    }
}

/* [] END OF FILE */
