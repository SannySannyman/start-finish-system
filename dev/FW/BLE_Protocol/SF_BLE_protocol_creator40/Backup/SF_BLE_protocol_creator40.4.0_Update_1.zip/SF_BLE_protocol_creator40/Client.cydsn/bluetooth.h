/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef BLUETOOTH_H
    #define BLUETOOTH_H

#include "project.h"
#include "..\common_files\debug.h"
#include "..\common_files\adv_packet.h"



BLE_advPacketsContent_t advData;


//void BLE_AppEventHandler(uint32 event, void* eventParam);
void BLE_Init(void);


#endif



/* [] END OF FILE */
