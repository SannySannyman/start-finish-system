/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "..\common_files\debug.h"
#include "bluetooth.h"
#include "LED_Display.h"
#include "DisplayData.h"

volatile uint8 displayNextFlag = 0;


CY_ISR(isr_DisplayNext_Handler)
{
    displayNextFlag = 1;
    Timer_Display_ClearInterrupt(Timer_Display_INTR_MASK_TC);
}

int main(void)
{
    uint8 num = 0;
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    DEBUG_Init();
    BLE_Init();
    LEDD_Init();
    Timer_Display_Start();
    isr_DisplayNext_StartEx(isr_DisplayNext_Handler);
    
    LEDD_GotoXY(0, 0);
    LEDD_Str("SF System v1.0");

    for(;;)
    {
        CyBle_ProcessEvents();
        if(displayNextFlag == 1)
        {
            displayNextFlag = 0;
            
            DisplayData_Skier(num);
            
            num++;
            if(num >= advData.ItemNum)
            {
                num = 0;
            }
        }
    }
}

/* [] END OF FILE */
