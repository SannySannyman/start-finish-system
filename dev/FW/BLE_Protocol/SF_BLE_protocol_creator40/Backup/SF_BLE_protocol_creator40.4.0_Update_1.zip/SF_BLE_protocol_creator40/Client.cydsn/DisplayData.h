/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef DISPLAYDATA_H
    #define DISPLAYDATA_H

#include "project.h"
#include "bluetooth.h"
#include "LED_Display.h"



void DisplayData_Skier(uint8 dataNum);


#endif



/* [] END OF FILE */
