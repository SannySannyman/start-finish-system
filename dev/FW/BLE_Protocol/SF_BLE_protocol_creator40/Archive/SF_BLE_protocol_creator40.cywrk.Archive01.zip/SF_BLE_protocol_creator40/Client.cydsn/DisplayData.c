/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "DisplayData.h"

#define TEMPBUF_LEN 20
char tempBuff[TEMPBUF_LEN];

void DisplayData_Skier(uint8 dataNum)
{
    if(dataNum < BLE_ADV_PACKET_COUNT && advData.ItemNum > 0)
    {
        LEDD_Clear();
        
        LEDD_GotoXY(0, 0);
        snprintf(tempBuff, TEMPBUF_LEN, "#%03u", advData.Data[dataNum].SkierNum);
        LEDD_Str(tempBuff);
        
        LEDD_GotoXY(25, 0);
        
        switch (advData.Data[dataNum].StatusByte)
        {
            case STATUS_STARTED:
                snprintf(tempBuff, TEMPBUF_LEN, "Started");
                break;
            case STATUS_FINISHED:
                snprintf(tempBuff, TEMPBUF_LEN, "Finished");
                break;
            case STATUS_CANCELED:
                snprintf(tempBuff, TEMPBUF_LEN, "Canceled");
                break;
        }
        LEDD_Str(tempBuff);
        
        if(advData.Data[dataNum].StatusByte == STATUS_FINISHED)
        {
            LEDD_GotoXY(0, 8);
            memset(tempBuff, 0, TEMPBUF_LEN);
            strncpy(tempBuff, advData.Data[dataNum].Text, BLE_ADV_PACKET_TEXTLEN);
            LEDD_Str(tempBuff);
            LEDD_PutCh(':');
        
            LEDD_GotoXY(31, 8);
            snprintf(tempBuff, TEMPBUF_LEN, "%02x:%02x.%02x", (uint8)((advData.Data[dataNum].TimeResult>>16)&0xFF),
                                                 (uint8)((advData.Data[dataNum].TimeResult>>8)&0xFF),
                                                 (uint8)((advData.Data[dataNum].TimeResult   )&0xFF));
            LEDD_Str(tempBuff);
        }
    }
}


/* [] END OF FILE */
