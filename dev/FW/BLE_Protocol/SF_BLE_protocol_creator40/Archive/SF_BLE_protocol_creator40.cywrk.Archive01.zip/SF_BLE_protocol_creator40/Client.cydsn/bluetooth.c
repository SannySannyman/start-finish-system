/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "bluetooth.h"


void BLE_PrintScanProgress(CYBLE_GAPC_ADV_REPORT_T* eventParam);
void BLE_AppEventHandler(uint32 event, void* eventParam);

void BLE_Init(void)
{
    advData.ItemNum = 0;
    advData.NextItem = 0;
    CyBle_Start(BLE_AppEventHandler);
}

void BLE_StartScan(uint8 scanIntervalType)
{
    CYBLE_API_RESULT_T apiResult;
    apiResult = CyBle_GapcStartScan(scanIntervalType);
	if(apiResult != CYBLE_ERROR_OK)
    {
        DBG_PRINTF("StartScan API Error: ");
        DEBUG_BLE_PrintApiResult(apiResult);
    }
    else
    {
        DBG_PRINTF("Start Scan \r\n");
    }
}


void BLE_ScanProgressEventHandler(CYBLE_GAPC_ADV_REPORT_T* eventParam)
{
    static uint8 prewPacket[CYBLE_GAP_MAX_ADV_DATA_LEN];
    uint8 SkierNumExistFlag = 0;
    uint8 dataWriteFlag = 0;
    uint8 i = 0;
    uint8 dataIndex = 0;
    

    
    if( eventParam->eventType != CYBLE_GAPC_SCAN_RSP &&
        eventParam->data[ADV_PACKET_UUID_LSB] == BLE_CUSTOM_SERVICE_UUID_LSB &&
        eventParam->data[ADV_PACKET_UUID_MSB] == BLE_CUSTOM_SERVICE_UUID_MSB &&
        eventParam->data[ADV_PACKET_ENDBYTE] == BLE_ADV_PACKET_ENDBYTE)
    {
        if(memcmp(prewPacket, eventParam->data, eventParam->dataLen) != 0) /*check for new packet*/
        {
            memcpy(prewPacket, eventParam->data, eventParam->dataLen);
            
            BLE_PrintScanProgress(eventParam);
        
            for(i = 0; i < advData.ItemNum; i++)    /*searcing skier number*/
            {
                if(advData.Data[i].SkierNum == eventParam->data[ADV_PACKET_SKIER_NUM]) 
                {
                    DBG_PRINTF("skier exist, i = %i, advData.ItemNum = %i\n\r", i, advData.ItemNum);
                    SkierNumExistFlag = 1;
                    dataIndex = i;
                    break;
                }
            }
            

            if(SkierNumExistFlag == 1)
            {
                if(advData.Data[i].StatusByte != eventParam->data[ADV_PACKET_STATUS_BYTE])
                {
                    DBG_PRINTF("new status byte: %x, old: %x\n\r", eventParam->data[ADV_PACKET_STATUS_BYTE], advData.Data[i].StatusByte);
                    dataWriteFlag = 1;
                }  
                else
                {
                    DBG_PRINTF("status byte not changed\n\r");
                }
            }
            else
            {
                DBG_PRINTF("new skier num: %i\n\r", eventParam->data[ADV_PACKET_SKIER_NUM]);
                dataIndex = advData.NextItem;
                dataWriteFlag = 1;
                
                advData.NextItem++;
                if(advData.NextItem >= BLE_ADV_PACKET_COUNT)
                {
                    advData.NextItem = 0;
                }
                
                if(advData.ItemNum < BLE_ADV_PACKET_COUNT)
                {
                    advData.ItemNum++;
                }
            }
            
            if(dataWriteFlag == 1)
            {
                Pin_RedLED_Write(~Pin_RedLED_Read());
                
                DBG_PRINTF("write new data\n\r");
                advData.Data[dataIndex].SkierNum = eventParam->data[ADV_PACKET_SKIER_NUM];
                advData.Data[dataIndex].StatusByte = eventParam->data[ADV_PACKET_STATUS_BYTE];
                
                advData.Data[dataIndex].TimeStart =  
                    (eventParam->data[ADV_PACKET_TIME_START_B3]<<24)|
                    (eventParam->data[ADV_PACKET_TIME_START_B2]<<16)|
                    (eventParam->data[ADV_PACKET_TIME_START_B1]<<8)|
                    (eventParam->data[ADV_PACKET_TIME_START_B0]);
                
                advData.Data[dataIndex].TimeFinish =
                    (eventParam->data[ADV_PACKET_TIME_FINISH_B3]<<24)|
                    (eventParam->data[ADV_PACKET_TIME_FINISH_B2]<<16)|
                    (eventParam->data[ADV_PACKET_TIME_FINISH_B1]<<8)|
                    (eventParam->data[ADV_PACKET_TIME_FINISH_B0]);
                
                advData.Data[dataIndex].TimeResult = 
                    (eventParam->data[ADV_PACKET_TIME_RESULT_B3]<<24)|
                    (eventParam->data[ADV_PACKET_TIME_RESULT_B2]<<16)|
                    (eventParam->data[ADV_PACKET_TIME_RESULT_B1]<<8)|
                    (eventParam->data[ADV_PACKET_TIME_RESULT_B0]);
                
                memcpy(advData.Data[dataIndex].Text, &eventParam->data[ADV_PACKET_TXT_START], BLE_ADV_PACKET_TEXTLEN);

                DBG_PRINTF("time result = %lx\n\r", advData.Data[dataIndex].TimeResult);
            }
            DBG_PRINTF("\n\r");
        }

    }

}


void BLE_AppEventHandler(uint32 event, void* eventParam)
{
    //CYBLE_API_RESULT_T apiResult;
        switch(event)
    {
        case CYBLE_EVT_STACK_ON:
            BLE_StartScan(CYBLE_SCANNING_FAST);
            break;

        case CYBLE_EVT_GAPC_SCAN_PROGRESS_RESULT:
            BLE_ScanProgressEventHandler((CYBLE_GAPC_ADV_REPORT_T *)eventParam);
            break;
            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            BLE_StartScan(CYBLE_SCANNING_FAST);
            break;

        default:
            break;
    }
    
    DEBUG_BLE_PrintAppEvent(event, eventParam);
}

void BLE_PrintScanProgress(CYBLE_GAPC_ADV_REPORT_T* eventParam)
{

    uint8 i = 0;

    DBG_PRINTF("Scan result: \n\r");
    DBG_PRINTF("event type:");
    switch (eventParam->eventType)
    {
        case CYBLE_GAPC_CONN_UNDIRECTED_ADV:
            DBG_PRINTF("CONN_UNDIRECTED_ADV\n\r");
            break;
            
        case CYBLE_GAPC_CONN_DIRECTED_ADV:
            DBG_PRINTF("CONN_DIRECTED_ADV\n\r");
            break;
            
        case CYBLE_GAPC_SCAN_UNDIRECTED_ADV:
            DBG_PRINTF("DIRECTED_ADV\n\r");
            break;
            
        case CYBLE_GAPC_NON_CONN_UNDIRECTED_ADV:
            DBG_PRINTF("NON_CONN_UNDIRECTED_ADV\n\r");
            break;
            
        case CYBLE_GAPC_SCAN_RSP:
            DBG_PRINTF("SCAN_RSP\n\r");
            break;
    }
    
    if(eventParam->eventType != CYBLE_GAPC_SCAN_RSP)
    {      
        DBG_PRINTF("ADV data: ");
        for(i = 0; i < eventParam->dataLen; i++)
        {
            DBG_PRINTF("%02x", eventParam->data[i]);
            if(i < eventParam->dataLen -1)
            {
                DBG_PRINTF(":");
            }
        }
        DBG_PRINTF("\n\r");
    }
    
    DBG_PRINTF("dataLen: %i \n\r", eventParam->dataLen);

}

/* [] END OF FILE */
