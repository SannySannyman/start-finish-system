/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "bluetooth.h"
#include "string.h"

BLE_advPacketsContent_t advData;


volatile uint8 nextPacketFlag = 0;

void BLE_ADV_NextPacket(void)
{
    nextPacketFlag = 1;
}

void BLE_ADV_UpdatePacket(BLE_advPacketData_t *data)
{
    if(data != NULL)
    {
        cyBle_discoveryData.advData[ADV_PACKET_UUID_DATALEN] = ADV_PACKET_LEN - 4; /* Length */
        cyBle_discoveryData.advData[ADV_PACKET_SERVICEDATA] = 0x16;      /* Service Data */
        cyBle_discoveryData.advData[ADV_PACKET_UUID_LSB] = BLE_CUSTOM_SERVICE_UUID_LSB;
        cyBle_discoveryData.advData[ADV_PACKET_UUID_MSB] = BLE_CUSTOM_SERVICE_UUID_MSB;
        
        cyBle_discoveryData.advData[ADV_PACKET_SKIER_NUM] = data->SkierNum;
        cyBle_discoveryData.advData[ADV_PACKET_STATUS_BYTE] = data->StatusByte;
        
		cyBle_discoveryData.advData[ADV_PACKET_TIME_START_B3] = (data->TimeStart>>24)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_START_B2] = (data->TimeStart>>16)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_START_B1] = (data->TimeStart>>8)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_START_B0] = (data->TimeStart)&0xFF;
		
		cyBle_discoveryData.advData[ADV_PACKET_TIME_FINISH_B3] = (data->TimeFinish>>24)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_FINISH_B2] = (data->TimeFinish>>16)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_FINISH_B1] = (data->TimeFinish>>8)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_FINISH_B0] = (data->TimeFinish)&0xFF;
		
		cyBle_discoveryData.advData[ADV_PACKET_TIME_RESULT_B3] = (data->TimeResult>>24)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_RESULT_B2] = (data->TimeResult>>16)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_RESULT_B1] = (data->TimeResult>>8)&0xFF;
		cyBle_discoveryData.advData[ADV_PACKET_TIME_RESULT_B0] = (data->TimeResult)&0xFF;
		
        memcpy(&cyBle_discoveryData.advData[ADV_PACKET_TXT_START], data->Text, BLE_ADV_PACKET_TEXTLEN);
        
        cyBle_discoveryData.advData[ADV_PACKET_ENDBYTE] = BLE_ADV_PACKET_ENDBYTE;
        
        /* ADV packet length */
        cyBle_discoveryData.advDataLen = ADV_PACKET_LEN;
        
        CyBle_GapUpdateAdvData(cyBle_discoveryModeInfo.advData, cyBle_discoveryModeInfo.scanRspData);
    }
    
}

void BLE_ADV_SetPacket(uint8 numOfPacket)
{  
    if(numOfPacket < advData.ItemNum)
    {
        BLE_ADV_UpdatePacket(&advData.Data[numOfPacket]);
    }
}



BLE_API_Result_t BLE_ADV_Process(void)
{
    if(nextPacketFlag == 1)
    {
        if(CyBle_GetBleSsState() == CYBLE_BLESS_STATE_EVENT_CLOSE)
        {
            nextPacketFlag = 0;
            
            BLE_ADV_SetPacket(advData.NextItem);
            
            advData.NextItem++;
            if(advData.NextItem >= advData.ItemNum)
            {
                advData.NextItem = 0;
            }
            return BLE_ADV_PACKET_UPDATED;
        }
    }
    return BLE_ADV_PACKET_UPD_WAIT;
}




void BLE_AppEventHandler(uint32 event, void* eventParam)
{
    //CYBLE_API_RESULT_T apiResult;
    DEBUG_BLE_PrintAppEvent(event, eventParam);
    
    switch(event)
    {
        case CYBLE_EVT_STACK_ON:
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            ///////
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            break;

        default:
            break;
    }

}


void BLE_Start(void)
{
    CyBle_Start(BLE_AppEventHandler);
}

void BLE_ADV_AddData(BLE_advPacketData_t *newData)
{
    int8 i = 0;
    uint8 buffIndex = 0;
    uint8 updateFlag = 0;
      
    for(i = 0; i < advData.ItemNum; i++)
    {
        if(newData->SkierNum == advData.Data[i].SkierNum)// data already in buffer, update
        {
            updateFlag = 1;
            break;
        }
    }
    
    if(updateFlag == 1)
    {
        buffIndex = i;
    }
    else
    {
        buffIndex = advData.NextItem;
        
        advData.NextItem++;
    
        if(advData.NextItem >= BLE_ADV_PACKET_COUNT)
        {
            advData.NextItem = 0;
        }
        
        if(advData.ItemNum < BLE_ADV_PACKET_COUNT)
        {
            advData.ItemNum++;
        }
    }
    
    advData.Data[buffIndex].SkierNum = newData->SkierNum;
    advData.Data[buffIndex].StatusByte = newData->StatusByte;
    advData.Data[buffIndex].TimeStart = newData->TimeStart;
    advData.Data[buffIndex].TimeFinish = newData->TimeFinish;
    advData.Data[buffIndex].TimeResult = newData->TimeResult;
    memcpy(advData.Data[buffIndex].Text, newData->Text, BLE_ADV_PACKET_TEXTLEN);
}   

/* [] END OF FILE */
