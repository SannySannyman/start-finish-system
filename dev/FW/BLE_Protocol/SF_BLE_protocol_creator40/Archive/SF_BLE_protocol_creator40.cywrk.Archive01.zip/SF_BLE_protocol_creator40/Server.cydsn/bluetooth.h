/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef BLUETOOTH_H
    #define BLUETOOTH_H
    
#include "project.h"
#include "..\common_files\debug.h"
#include "..\common_files\adv_packet.h"


typedef enum
{
    BLE_ADV_PACKET_UPDATED,
    BLE_ADV_PACKET_UPD_WAIT,
    
    
}BLE_API_Result_t;
    
void BLE_ADV_AddData(BLE_advPacketData_t *newData);
void BLE_ADV_NextPacket(void);
void BLE_ADV_SetPacket(uint8 numOfPacket);
BLE_API_Result_t BLE_ADV_Process(void);
void BLE_Start(void);





#endif
/* [] END OF FILE */
